import 'package:flutter/material.dart';

void main() {
  runApp(const NahdaDzApp());
}

class AppColors {
  static const green = Color(0xFF006B45);
  static const darkGreen = Color(0xFF004B32);
  static const gold = Color(0xFFD7A72B);
  static const red = Color(0xFFD91E2E);
  static const bg = Color(0xFFF6F8F7);
}

class NahdaDzApp extends StatelessWidget {
  const NahdaDzApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'النهضة Dz',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.green),
        fontFamily: 'sans',
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: HomeShell(),
      ),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;

  final pages = const [
    HomePage(),
    ElitePage(),
    ProjectsPage(),
    DiscussionsPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.groups_outlined), selectedIcon: Icon(Icons.groups), label: 'النخبة'),
          NavigationDestination(icon: Icon(Icons.lightbulb_outline), selectedIcon: Icon(Icons.lightbulb), label: 'المشاريع'),
          NavigationDestination(icon: Icon(Icons.forum_outlined), selectedIcon: Icon(Icons.forum), label: 'النقاشات'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}

class BrandHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  const BrandHeader({super.key, required this.title, this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 10),
      child: Row(
        children: [
          Container(
            width: 46, height: 46,
            decoration: BoxDecoration(
              color: AppColors.darkGreen,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Center(
              child: Text('Dz', style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900, fontSize: 18)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: AppColors.darkGreen)),
                if (subtitle != null)
                  Text(subtitle!, style: const TextStyle(color: Colors.black54)),
              ],
            ),
          ),
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.only(bottom: 20),
      children: [
        const BrandHeader(title: 'النهضة Dz', subtitle: 'نلتقي لنفكر.. نتعاون لننهض'),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [AppColors.darkGreen, AppColors.green]),
            borderRadius: BorderRadius.circular(24),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('معًا نبني جزائر المستقبل', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900)),
              SizedBox(height: 8),
              Text('منصة تجمع الكفاءات والأفكار والمشاريع من مختلف أنحاء الجزائر.',
                  style: TextStyle(color: Colors.white70, height: 1.5)),
            ],
          ),
        ),
        const SectionTitle('اكتشف المنصة'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            children: const [
              QuickAction(Icons.groups, 'النخبة'),
              QuickAction(Icons.lightbulb, 'المشاريع'),
              QuickAction(Icons.handshake, 'التعاون'),
              QuickAction(Icons.event, 'الفعاليات'),
              QuickAction(Icons.menu_book, 'المعرفة'),
              QuickAction(Icons.forum, 'النقاشات'),
              QuickAction(Icons.mail, 'الرسائل'),
              QuickAction(Icons.more_horiz, 'المزيد'),
            ],
          ),
        ),
        const SectionTitle('أحدث المنشورات'),
        const PostCard(
          name: 'أحمد بن يحيى',
          role: 'مهندس معماري',
          text: 'فكرة مشروع في مجال الطاقات المتجددة تبحث عن شركاء من أصحاب الخبرة.',
          tag: 'مشروع',
        ),
        const PostCard(
          name: 'د. أمينة منصوري',
          role: 'باحثة وأستاذة جامعية',
          text: 'نقاش اليوم: كيف يمكن تحويل المعرفة الجامعية إلى مشاريع قابلة للتطبيق؟',
          tag: 'نقاش',
        ),
      ],
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
    child: Text(text, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
  );
}

class QuickAction extends StatelessWidget {
  final IconData icon; final String label;
  const QuickAction(this.icon, this.label, {super.key});
  @override
  Widget build(BuildContext context) => Column(
    children: [
      Expanded(child: Container(
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: Center(child: Icon(icon, color: AppColors.green, size: 28)),
      )),
      const SizedBox(height: 5),
      Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
    ],
  );
}

class PostCard extends StatelessWidget {
  final String name, role, text, tag;
  const PostCard({super.key, required this.name, required this.role, required this.text, required this.tag});
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
    elevation: 0,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const CircleAvatar(backgroundColor: Color(0xFFE1EFE9), child: Icon(Icons.person, color: AppColors.green)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, style: const TextStyle(fontWeight: FontWeight.w900)),
            Text(role, style: const TextStyle(fontSize: 12, color: Colors.black54)),
          ])),
          Chip(label: Text(tag), visualDensity: VisualDensity.compact),
        ]),
        const SizedBox(height: 12),
        Text(text, style: const TextStyle(height: 1.5)),
        const SizedBox(height: 10),
        const Row(children: [
          Icon(Icons.favorite_border, size: 20), SizedBox(width: 18),
          Icon(Icons.chat_bubble_outline, size: 20), SizedBox(width: 18),
          Icon(Icons.share_outlined, size: 20),
        ]),
      ]),
    ),
  );
}

class ElitePage extends StatelessWidget {
  const ElitePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    children: [
      const BrandHeader(title: 'النخبة', subtitle: 'اكتشف الكفاءات والخبرات'),
      const SearchBox(hint: 'ابحث عن عضو أو مجال...'),
      const FilterRow(items: ['الكل', 'أطباء', 'مهندسون', 'أساتذة', 'باحثون']),
      ...const [
        PersonCard('د. أمينة منصوري', 'طبيبة وباحثة في أمراض القلب', 'الجزائر العاصمة'),
        PersonCard('أ. كريم بن أحمد', 'مهندس مدني ومستشار', 'وهران'),
        PersonCard('أ. سعاد علوي', 'أستاذة جامعية - علوم التسيير', 'قسنطينة'),
        PersonCard('د. فارس قادري', 'باحث في الذكاء الاصطناعي', 'عنابة'),
      ],
    ],
  );
}

class PersonCard extends StatelessWidget {
  final String name, role, city;
  const PersonCard(this.name, this.role, this.city, {super.key});
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
    elevation: 0,
    child: ListTile(
      leading: const CircleAvatar(child: Icon(Icons.person)),
      title: Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Text('$role\n$city'),
      isThreeLine: true,
      trailing: OutlinedButton(onPressed: () {}, child: const Text('متابعة')),
    ),
  );
}

class ProjectsPage extends StatelessWidget {
  const ProjectsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    children: [
      const BrandHeader(title: 'الأفكار والمشاريع', subtitle: 'حوّل الفكرة إلى تعاون حقيقي'),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.add), label: const Text('أضف فكرة أو مشروعًا')),
      ),
      const FilterRow(items: ['الكل', 'أفكار جديدة', 'مشاريع', 'شراكات']),
      const ProjectCard('مشروع تطبيق جزائري للتعليم الذكي', 'تعليم • تكنولوجيا', Icons.school),
      const ProjectCard('منصة ذكية للزراعة الحديثة', 'فلاحة • ابتكار', Icons.agriculture),
      const ProjectCard('مشروع طاقة شمسية مجتمعية', 'طاقة • استثمار', Icons.solar_power),
      const ProjectCard('حلول رقمية للمؤسسات الصغيرة', 'رقمنة • أعمال', Icons.business),
    ],
  );
}

class ProjectCard extends StatelessWidget {
  final String title, category; final IconData icon;
  const ProjectCard(this.title, this.category, this.icon, {super.key});
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
    elevation: 0,
    child: ListTile(
      contentPadding: const EdgeInsets.all(14),
      leading: Container(width: 54, height: 54, decoration: BoxDecoration(color: const Color(0xFFE7F2EE), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: AppColors.green)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text(category)),
      trailing: const Icon(Icons.arrow_back_ios_new, size: 16),
    ),
  );
}

class DiscussionsPage extends StatelessWidget {
  const DiscussionsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    children: [
      const BrandHeader(title: 'النقاشات', subtitle: 'أفكار وآراء وحوار محترم'),
      const SearchBox(hint: 'ابحث في النقاشات...'),
      const FilterRow(items: ['الكل', 'تكنولوجيا', 'اقتصاد', 'تعليم', 'مجتمع']),
      const DiscussionCard('مستقبل الذكاء الاصطناعي في الجزائر', '32 ردًا', Icons.auto_awesome),
      const DiscussionCard('كيف نطور التعليم العالي في الجزائر؟', '58 ردًا', Icons.school),
      const DiscussionCard('دور الشباب في الاقتصاد الوطني', '47 ردًا', Icons.groups),
      const DiscussionCard('الطاقات المتجددة: فرصة حقيقية للجزائر', '39 ردًا', Icons.bolt),
    ],
  );
}

class DiscussionCard extends StatelessWidget {
  final String title, replies; final IconData icon;
  const DiscussionCard(this.title, this.replies, this.icon, {super.key});
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
    elevation: 0,
    child: ListTile(
      leading: CircleAvatar(backgroundColor: const Color(0xFFE8F3EE), child: Icon(icon, color: AppColors.green)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Text('$replies • آخر نشاط منذ ساعتين'),
      trailing: const Icon(Icons.chevron_left),
    ),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    children: [
      const BrandHeader(title: 'ملفي الشخصي'),
      Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: AppColors.darkGreen, borderRadius: BorderRadius.circular(22)),
        child: const Column(children: [
          CircleAvatar(radius: 40, backgroundColor: Colors.white, child: Icon(Icons.person, size: 48, color: AppColors.green)),
          SizedBox(height: 10),
          Text('أحمد بن سالم', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
          Text('مهندس • الجزائر العاصمة', style: TextStyle(color: Colors.white70)),
          SizedBox(height: 15),
          Text('عضو موثّق', style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.bold)),
        ]),
      ),
      const ProfileTile(Icons.badge_outlined, 'المعلومات الشخصية'),
      const ProfileTile(Icons.workspace_premium_outlined, 'الخبرات والمؤهلات'),
      const ProfileTile(Icons.lightbulb_outline, 'مشاريعي'),
      const ProfileTile(Icons.bookmark_outline, 'المحفوظات'),
      const ProfileTile(Icons.settings_outlined, 'الإعدادات'),
    ],
  );
}

class ProfileTile extends StatelessWidget {
  final IconData icon; final String title;
  const ProfileTile(this.icon, this.title, {super.key});
  @override
  Widget build(BuildContext context) => ListTile(leading: Icon(icon, color: AppColors.green), title: Text(title), trailing: const Icon(Icons.chevron_left));
}

class SearchBox extends StatelessWidget {
  final String hint;
  const SearchBox({super.key, required this.hint});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    child: TextField(decoration: InputDecoration(
      hintText: hint, prefixIcon: const Icon(Icons.search),
      filled: true, fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
    )),
  );
}

class FilterRow extends StatelessWidget {
  final List<String> items;
  const FilterRow({super.key, required this.items});
  @override
  Widget build(BuildContext context) => SizedBox(
    height: 52,
    child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      scrollDirection: Axis.horizontal,
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(width: 8),
      itemBuilder: (_, i) => Chip(label: Text(items[i])),
    ),
  );
}